# FACA UM PROGRAMA QUE SOLICITE O NOME DO USUARIO E EXIBA UMA MENSAGEM DE BOAS VINDAS PERSONALIZADA

nome = input('Digite o seu nome: ')
print('É um prazer te conhecer, {}!' .format(nome))
