# LEIA UM NÚMERO E EXIBA SEU ANTECESSOR E SUCESSOR

n = int(input('Digite um número: '))

print('Número digitado {}, seu antecessor é  {} e seu sucessor é {}' .format(n, (n-1), (n+1)))
