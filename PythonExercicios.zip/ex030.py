#CRIE UM PROGRAMA QUE LEIA UM NÚMERO INTEIRO E MOSTRE NA TELA SE ELE É PAR OU ÍMPAR

n = int(input('Digite um número inteiro qualquer: '))

print('Número PAR!!!' if n % 2 == 0 else 'Número ÍMPAR!!!')
