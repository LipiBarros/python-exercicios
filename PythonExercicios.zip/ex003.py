# SOLICITE DOIS NUMEROS AO USUARIO E EXIBA A SOMA DELES

n1 = int(input('Digite um numero: '))
n2 = int(input('Digite outro numero: '))

soma = n1 + n2

print('A soma de {} + {} é igual a {} !'.format(n1, n2, soma))
