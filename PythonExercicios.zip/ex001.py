# FAÇA UM PROGRAMA QUE ESCREVA 'Olá, mundo!' NA TELA

print('Olá, mundo!')
