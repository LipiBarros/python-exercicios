# FAÇA UM PROGRAMA QUE LEIA O SALÁRIO DE UM FUNCIONÁRIO E INFORME SEU NOVO SALÁRIO COM 15% DE AUMENTO

s = float(input('Qual o salário do funcionário ? R$'))

print('O salário atual é R${:.2f}, o novo salário com 15% de aumento é R${:.2f}' .format(s, s * 1.15))
